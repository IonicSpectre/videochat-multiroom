# VideoChat Multiroom

Una videochat multiroom completa con:
- Autenticazione (login/registrazione/guest)
- WebRTC per videochiamate
- Chat testuale con messaggi privati
- Sistema di stanze multiple
- Pannello di controllo admin
- Database MySQL

## Requisiti
- Node.js 16+
- MySQL 8+
- NPM 7+

## Installazione
1. Clona il repository
2. Configura il file `.env` (vedi `.env.example`)
3. Installa le dipendenze:
   ```bash
   npm install
   cd client && npm install && cd ..