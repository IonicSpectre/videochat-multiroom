require('dotenv').config();
const express = require('express');
const socketio = require('socket.io');
const { Sequelize } = require('sequelize');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Configurazione MySQL
const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: 'mysql',
    logging: false
  }
);

// Test connessione DB
(async () => {
  try {
    await sequelize.authenticate();
    console.log('Connessione al DB MySQL riuscita!');
  } catch (error) {
    console.error('Errore di connessione al DB:', error);
  }
})();

// Avvio server
const server = app.listen(process.env.PORT || 3000, () => {
  console.log(`Server in ascolto sulla porta ${process.env.PORT || 3000}`);
});

// Configurazione Socket.io
const io = socketio(server, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:8080",
    methods: ["GET", "POST"]
  }
});

// Gestione connessioni WebSocket
require('./sockets/chat')(io, sequelize);

// Rotte API
app.use('/api/auth', require('./routes/auth'));
app.use('/api/rooms', require('./routes/rooms'));
app.use('/api/users', require('./routes/users'));
app.use('/api/admin', require('./routes/admin'));