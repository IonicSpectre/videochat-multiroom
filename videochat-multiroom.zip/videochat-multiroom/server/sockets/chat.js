module.exports = (io, db) => {
  io.on('connection', (socket) => {
    console.log(`New connection: ${socket.id}`);
    
    // Gestione join room
    socket.on('joinRoom', async ({ userId, roomId }) => {
      try {
        const user = await db.User.findByPk(userId);
        const room = await db.Room.findByPk(roomId);
        
        if (!user || !room) {
          return socket.emit('error', 'User or room not found');
        }
        
        await user.addRoom(room);
        socket.join(roomId);
        
        io.to(roomId).emit('userJoined', {
          userId: user.id,
          username: user.username,
          role: user.role
        });
        
        // Invia storico messaggi
        const messages = await db.Message.findAll({
          where: { roomId },
          include: [{ model: db.User, attributes: ['id', 'username', 'role'] }],
          order: [['createdAt', 'ASC']],
          limit: 100
        });
        
        socket.emit('messageHistory', messages);
      } catch (err) {
        console.error(err);
        socket.emit('error', 'Error joining room');
      }
    });
    
    // Gestione invio messaggi
    socket.on('sendMessage', async ({ userId, roomId, text }) => {
      try {
        const user = await db.User.findByPk(userId);
        const room = await db.Room.findByPk(roomId);
        
        if (!user || !room) {
          return socket.emit('error', 'User or room not found');
        }
        
        if (user.isBanned) {
          return socket.emit('error', 'You are banned');
        }
        
        const message = await db.Message.create({
          text,
          userId,
          roomId
        });
        
        const messageWithUser = await db.Message.findByPk(message.id, {
          include: [{ model: db.User, attributes: ['id', 'username', 'role'] }]
        });
        
        io.to(roomId).emit('newMessage', messageWithUser);
        
        // Log del messaggio
        await db.Log.create({
          eventType: 'message',
          userId,
          roomId,
          data: { text }
        });
      } catch (err) {
        console.error(err);
        socket.emit('error', 'Error sending message');
      }
    });
    
    // Gestione disconnessione
    socket.on('disconnect', () => {
      console.log(`User disconnected: ${socket.id}`);
    });
  });
};