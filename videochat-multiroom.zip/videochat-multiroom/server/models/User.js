module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define('User', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false
    },
    role: {
      type: DataTypes.ENUM('founder', 'superadmin', 'admin', 'moderator', 'vip', 'user', 'guest'),
      defaultValue: 'user'
    },
    isBanned: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    lastIp: DataTypes.STRING,
    vipColor: DataTypes.STRING,
    avatar: DataTypes.STRING
  }, {
    timestamps: true
  });

  User.associate = (models) => {
    User.hasMany(models.Message);
    User.hasMany(models.PrivateMessage);
    User.belongsToMany(models.Room, { through: 'RoomUsers' });
  };

  return User;
};