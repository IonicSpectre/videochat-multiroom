const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const config = require('../server/config/config');

console.log('Starting database setup...');

// Crea il database se non esiste
const createDbCommand = `mysql -u ${config.development.username} -p${config.development.password} -e "CREATE DATABASE IF NOT EXISTS ${config.development.database};"`;

exec(createDbCommand, (error, stdout, stderr) => {
  if (error) {
    console.error('Error creating database:', error);
    return;
  }

  console.log('Database created or already exists');
  
  // Esegui le migrazioni
  const migrateCommand = 'npx sequelize-cli db:migrate';
  exec(migrateCommand, (migrateError, migrateStdout, migrateStderr) => {
    if (migrateError) {
      console.error('Error running migrations:', migrateError);
      return;
    }

    console.log('Migrations executed successfully');
    
    // Esegui i seeders
    const seedCommand = 'npx sequelize-cli db:seed:all';
    exec(seedCommand, (seedError, seedStdout, seedStderr) => {
      if (seedError) {
        console.error('Error running seeders:', seedError);
        return;
      }

      console.log('Seeders executed successfully');
      console.log('Database setup completed!');
      
      // Crea il file di lock per indicare che l'installazione è completa
      fs.writeFileSync(path.join(__dirname, '../INSTALLED'), '');
    });
  });
});