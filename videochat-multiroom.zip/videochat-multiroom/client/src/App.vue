<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  created() {
    // Verifica autenticazione all'avvio
    this.$store.dispatch('auth/checkAuth');
  }
}
</script>

<style>
/* Stili globali */
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap');

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Roboto', sans-serif;
}

#app {
  min-height: 100vh;
  background-color: #f5f5f5;
}
</style>