<template>
  <div class="login-container">
    <div class="login-box">
      <h1>VideoChat Login</h1>
      
      <form @submit.prevent="handleLogin" v-if="!isRegistering">
        <div class="form-group">
          <label>Username</label>
          <input v-model="loginData.username" required>
        </div>
        
        <div class="form-group">
          <label>Password</label>
          <input v-model="loginData.password" type="password" required>
        </div>
        
        <button type="submit">Login</button>
        <button type="button" @click="handleGuestLogin">Enter as Guest</button>
        
        <p v-if="enableRegistration">
          Don't have an account? 
          <a href="#" @click.prevent="isRegistering = true">Register here</a>
        </p>
      </form>
      
      <form @submit.prevent="handleRegister" v-else>
        <div class="form-group">
          <label>Username</label>
          <input v-model="registerData.username" required>
        </div>
        
        <div class="form-group">
          <label>Email</label>
          <input v-model="registerData.email" type="email" required>
        </div>
        
        <div class="form-group">
          <label>Password</label>
          <input v-model="registerData.password" type="password" required>
        </div>
        
        <div class="form-group">
          <label>Confirm Password</label>
          <input v-model="registerData.confirmPassword" type="password" required>
        </div>
        
        <button type="submit">Register</button>
        <button type="button" @click="isRegistering = false">Back to Login</button>
      </form>
      
      <div v-if="error" class="error-message">{{ error }}</div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { useAuthStore } from '@/store/modules/auth';

export default {
  setup() {
    const authStore = useAuthStore();
    const enableRegistration = ref(true);
    const isRegistering = ref(false);
    const error = ref('');
    
    const loginData = ref({
      username: '',
      password: ''
    });
    
    const registerData = ref({
      username: '',
      email: '',
      password: '',
      confirmPassword: ''
    });
    
    const checkRegistrationStatus = async () => {
      try {
        const response = await axios.get('/api/auth/registration-status');
        enableRegistration.value = response.data.enabled;
      } catch (err) {
        console.error('Error checking registration status:', err);
      }
    };
    
    const handleLogin = async () => {
      error.value = '';
      try {
        await authStore.login(loginData.value);
      } catch (err) {
        error.value = err;
      }
    };
    
    const handleGuestLogin = async () => {
      error.value = '';
      try {
        await authStore.guestLogin();
      } catch (err) {
        error.value = err;
      }
    };
    
    const handleRegister = async () => {
      error.value = '';
      if (registerData.value.password !== registerData.value.confirmPassword) {
        error.value = 'Passwords do not match';
        return;
      }
      
      try {
        await authStore.register({
          username: registerData.value.username,
          email: registerData.value.email,
          password: registerData.value.password
        });
      } catch (err) {
        error.value = err;
      }
    };
    
    onMounted(() => {
      checkRegistrationStatus();
    });
    
    return {
      enableRegistration,
      isRegistering,
      loginData,
      registerData,
      error,
      handleLogin,
      handleGuestLogin,
      handleRegister
    };
  }
};
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.login-box {
  background: white;
  padding: 2rem;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width: 400px;
  max-width: 90%;
}

h1 {
  text-align: center;
  margin-bottom: 1.5rem;
  color: #333;
}

.form-group {
  margin-bottom: 1rem;
}

label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
}

input {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 1rem;
}

button {
  width: 100%;
  padding: 0.75rem;
  margin-top: 0.5rem;
  background: #4a6cf7;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1rem;
  cursor: pointer;
  transition: background 0.3s;
}

button:hover {
  background: #3a5bd9;
}

button[type="button"] {
  background: #6c757d;
}

button[type="button"]:hover {
  background: #5a6268;
}

.error-message {
  color: #dc3545;
  margin-top: 1rem;
  text-align: center;
}

a {
  color: #4a6cf7;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}
</style>