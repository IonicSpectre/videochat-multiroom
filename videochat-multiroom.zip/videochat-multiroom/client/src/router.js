import { createRouter, createWebHistory } from 'vue-router';
import LoginView from '@/views/LoginView.vue';
import RoomListView from '@/views/RoomListView.vue';
import ChatView from '@/views/ChatView.vue';
import AdminPanelView from '@/views/AdminPanelView.vue';
import { useAuthStore } from '@/store/modules/auth';

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginView,
    meta: { guestOnly: true }
  },
  {
    path: '/rooms',
    name: 'RoomList',
    component: RoomListView,
    meta: { requiresAuth: true }
  },
  {
    path: '/chat/:roomId',
    name: 'Chat',
    component: ChatView,
    meta: { requiresAuth: true },
    props: true
  },
  {
    path: '/admin',
    name: 'AdminPanel',
    component: AdminPanelView,
    meta: { requiresAuth: true, requiresAdmin: true }
  }
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
});

router.beforeEach(async (to, from, next) => {
  const authStore = useAuthStore();
  
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    try {
      await authStore.checkAuth();
    } catch (error) {
      return next('/login');
    }
  }

  if (to.meta.guestOnly && authStore.isAuthenticated) {
    return next('/rooms');
  }

  if (to.meta.requiresAdmin && authStore.user?.role !== 'admin' && authStore.user?.role !== 'superadmin' && authStore.user?.role !== 'founder') {
    return next('/rooms');
  }

  next();
});

export default router;