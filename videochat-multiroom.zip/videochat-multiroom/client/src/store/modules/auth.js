import { defineStore } from 'pinia';
import { ref } from 'vue';
import axios from 'axios';
import router from '@/router';

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null);
  const token = ref(localStorage.getItem('token'));
  const isAuthenticated = ref(false);

  const setAuth = (userData, authToken) => {
    user.value = userData;
    token.value = authToken;
    isAuthenticated.value = true;
    localStorage.setItem('token', authToken);
    axios.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
  };

  const clearAuth = () => {
    user.value = null;
    token.value = null;
    isAuthenticated.value = false;
    localStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
  };

  const checkAuth = async () => {
    if (token.value) {
      try {
        const response = await axios.get('/api/auth/check');
        setAuth(response.data.user, token.value);
      } catch (error) {
        clearAuth();
      }
    }
  };

  const login = async (credentials) => {
    try {
      const response = await axios.post('/api/auth/login', credentials);
      setAuth(response.data.user, response.data.token);
      router.push('/rooms');
    } catch (error) {
      throw error.response?.data?.message || 'Login failed';
    }
  };

  const guestLogin = async () => {
    try {
      const response = await axios.post('/api/auth/guest');
      setAuth(response.data.user, response.data.token);
      router.push('/rooms');
    } catch (error) {
      throw error.response?.data?.message || 'Guest login failed';
    }
  };

  const register = async (userData) => {
    try {
      const response = await axios.post('/api/auth/register', userData);
      setAuth(response.data.user, response.data.token);
      router.push('/rooms');
    } catch (error) {
      throw error.response?.data?.message || 'Registration failed';
    }
  };

  const logout = () => {
    clearAuth();
    router.push('/login');
  };

  return {
    user,
    token,
    isAuthenticated,
    checkAuth,
    login,
    guestLogin,
    register,
    logout
  };
});