module.exports = {
  roles: ['guest', 'user', 'vip', 'moderator', 'admin', 'superadmin', 'founder']
};
